function setup() {
  createCanvas(400, 400);
  background(255);
  fill(0);
  rect(100,0,100,100);
  rect(300,0,100,100);
  rect(0,100,100,100);
  rect(200,100,100,100);
  rect(100,200,100,100);
  rect(300,200,100,100);
  rect(0,300,100,100);
  rect(200,300,100,100);
}

function draw() {
}