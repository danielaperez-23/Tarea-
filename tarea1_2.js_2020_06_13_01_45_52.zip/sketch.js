function setup() {
  createCanvas(400, 400);
  background(0);
  stroke(255);
  line(200,0,200,200);
  line(200,200,0,400);
  line(200,200,400,400);
}

function draw() {
  
}