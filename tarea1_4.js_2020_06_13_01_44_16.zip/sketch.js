function setup() {
  createCanvas(400, 400);
  background(255);
  strokeWeight(25);
  stroke(255,0,0);
  ellipse(200,200,300,300);
  line(85,105,315,295)
}

function draw() {
}