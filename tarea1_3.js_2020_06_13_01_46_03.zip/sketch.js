function setup() {
  createCanvas(300, 300); 
  background(220);
  noStroke(0,0,100,300);
  fill(255,0,0);
  rect(0,0,100,300);
  fill(50,255,0);
  rect(100,0,100,300);
  fill(0,0,255);
  rect(200,0,100,300);
  


}

function draw() {
  
}